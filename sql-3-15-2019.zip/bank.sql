create database bank;
use bank;
create table customers (
	customer_id int not null  primary key,
    full_name nvarchar(50) not null ,
    address nvarchar(100),
    email nvarchar(70),
    phone varchar(15)
);
 
 create table accounts (
	account_id int not null auto_increment primary key,
    customer_id int not null UNIQUE ,
    account_type varchar(30),
    date_sign_in date,
    balance float,
    constraint account_type_CK check (account_type = 'VIP' or account_type = 'normal' or account_type = 'businesss' )
);
    
    alter table accounts add constraint account_id_FK foreign key (customer_id) references customers(customer_id);
    
 create table transactions (
	tran_ID int not null primary key,
    account_id int not null,
    Tran_date date ,
    amount float,
	description varchar(100),
    constraint transactions_FK foreign key (account_id) references accounts(account_id)
);
 
 create table email (
	email varchar(30) not null primary key,
    customer_id int not null
);

alter table email add constraint email_FK foreign key (customer_id) references customers(customer_id);
 
  create table phone (
	phone varchar(30) not null primary key,
    customer_id int not null
);

alter table phone add constraint phone_FK foreign key (customer_id) references customers(customer_id);
 
 
 