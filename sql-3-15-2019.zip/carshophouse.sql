create database carshoping;
use carshoping;
create table customer(
	customernumber int auto_increment primary key,
    Employees_ID int not null,
    name nvarchar(50) not null,
    phonenumber varchar(20) not null,
    address nvarchar(100) not null,
    constraint Employees_ID_FK foreign key (Employees_ID) references Employees(Employees_ID)
);

create table Product_stypes (
	Product_type varchar(15) primary key,
    description nvarchar(100) not null
);

create table Products  (
	productcode int primary key not null,
    Product_type varchar(15)  not null,
    name_product nvarchar(25) not null,
    supplier nvarchar(50),
    quanlity int not null,
    price float not null,
    constraint Product_FK foreign key ( Product_type) references Product_stypes(Product_type)
);

create table Odders(
	ordernumber int primary key,
    customernumber int not null,
    date_Purchase date not null,
    date_require date not null,
    real_date_Purchase date not null,
    quanlity_order int not null,
    price int not null,
    constraint Odders_FK foreign key (customernumber) references customer(customernumber)
);

create table Odders_Payment_relationship(
	ordernumber int not null, 
    productcode int not null, 
    foreign key (ordernumber) references Odders(ordernumber),
    foreign key (productcode) references Products(productcode),
	unique (ordernumber,productcode)
);

create table payment(
	payment_number int primary key,
    customernumber int not null,
    date_payment date not null,
    amount_monney int not null,
    constraint payment_FK foreign key (customernumber) references customer(customernumber)
);

create table Employees (
	Employees_ID  int primary key,
    Offices_number int not null,
    Name_employee nvarchar(20) not null,
    email varchar (20) not null,
    job_type nvarchar(30) not null,
    constraint  Offices_number_FK foreign key (Offices_number) references Offices(Offices_number)
);

create table Offices  (
	Offices_number int primary key,
	address nvarchar(30) not null,
    phone_number varchar(20) not null,
    country varchar(10) not null
);




