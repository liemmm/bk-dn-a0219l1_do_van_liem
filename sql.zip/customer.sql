use customer;
SELECT * FROM customer;
SELECT CUST_name, PHONE_NO , CUST_CITY, CUST_COUNTRY FROM customers ;
SELECT * FROM customer WHERE CUST_name = 'Bolt';
SELECT * FROM customer WHERE CUST_name like '%A%';
SELECT * FROM customer WHERE CUST_CITY IN ('New York',' London',' Mumbai','Chennai') ;




